export interface GoVoters {
    id: Number;
	name: String;
	age: Number;
	fatherName: String;
	gender: String;
	aadharNumber: Number;
	email: String;
	phoneNumber: Number;
}