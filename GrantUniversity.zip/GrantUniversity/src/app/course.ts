export class Course {

    id: number;
    courseName: string;
    courseDuration: string;
    courseEligibility: string;
    courseFee: number;
}
