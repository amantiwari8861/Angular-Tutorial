import { TestBed, fakeAsync, tick } from '@angular/core/testing';
import { CourseService } from './course.service';

describe('CourseService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

});
