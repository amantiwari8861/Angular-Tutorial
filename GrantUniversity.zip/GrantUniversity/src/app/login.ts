export class Login {
    id: number;
    password: string;
}
